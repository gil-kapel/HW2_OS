#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>

asmlinkage long sys_hello(void){
	printk("Hello, World!\n"); 
	return 0;
}

asmlinkage long sys_set_weight(int weight){
	if(weight < 0 ) return -EINVAL;
	current->weight = weight;
	return 0;
}

asmlinkage long sys_get_weight(void){
	if(current->weight < 0 ) return 0;
	else return current->weight;
}

long get_leaf_sum(struct task_struct *task){
	struct task_struct *task1;
	struct list_head *iter;
	long sum = 0;
	list_for_each(iter, &task->children){
		task1 = list_entry(iter, struct task_struct, sibling);
		if(list_empty(&task1->children)) sum+= task1->weight;
		else sum += get_leaf_sum(task1);
 	}
	return sum;
}

asmlinkage long sys_get_leaf_children_sum(void){
	if(list_empty(&current->children)) return -ECHILD;
	return get_leaf_sum(current);
}

asmlinkage long sys_get_heaviest_ancestor(void){
	struct task_struct *task;
	task = current;
	pid_t pid = current->pid;
	long max_weight = current->weight;
	while(task->pid != 1){
		task = task->parent;
		if(task->weight > max_weight){
			max_weight = task->weight;
			pid = task->pid;
		}
	}
	return pid;
}
